package com.flashsale.falshsale;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FalshSaleApplicationTests {

    @Test
    void contextLoads() {
    }

}
