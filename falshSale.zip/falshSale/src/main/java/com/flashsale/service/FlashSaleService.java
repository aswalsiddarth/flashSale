package com.flashsale.service;

import com.flashsale.dto.AddItemDto;
import com.flashsale.dto.ResponseEntity;
import com.flashsale.model.Cart;

public interface FlashSaleService {
    ResponseEntity<Cart> addItemToCart(AddItemDto addItemDto);

}
