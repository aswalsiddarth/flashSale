package com.flashsale.service;

import com.flashsale.dto.AddItemDto;
import com.flashsale.dto.ResponseEntity;
import com.flashsale.exception.AlreadyOrderedException;
import com.flashsale.exception.BadRequestException;
import com.flashsale.exception.ItemOutOfStockException;
import com.flashsale.model.Cart;
import com.flashsale.model.Item;
import com.flashsale.model.ItemList;
import com.flashsale.repository.CartRepo;
import com.flashsale.repository.ItemListRepo;
import com.flashsale.repository.ItemRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class FlashSaleServiceImpl implements FlashSaleService {

    @Autowired
    private CartRepo cartRepo;

    @Autowired
    private ItemRepo itemRepo;

    @Autowired
    private ItemListRepo itemListRepo;


    @Override
    public ResponseEntity<Cart> addItemToCart(AddItemDto addItemDto) {
        String userId;
        try {
            validateInput(addItemDto);
            userId = addItemDto.getUser().getId();
            Item item = itemRepo.getItemById(addItemDto.getItem().getId());
            checkItemAvailability(item);
            ItemList itemList = itemListRepo.getItemListByUserId(userId);
            checkInItemList(itemList, item);
            Cart cart = addItemToTheCart(userId, item);
            ResponseEntity<Cart> responseEntity = ResponseEntity.builder()
                    .responseBody(cart)
                    .responseMessage("item added successfull")
                    .responseStatus(200).
                    build();
            return responseEntity;
        } catch (Exception ex) {

        }
        return null;
    }

    private void checkInItemList(ItemList itemList, Item item) throws AlreadyOrderedException {
        if (itemList.getItems().contains(item)) {
            throw new AlreadyOrderedException("Item already ordered from this account");
        }

    }

    private Cart addItemToTheCart(String userId, Item item) {
        item.setQuantity(item.getQuantity() - 1);
        itemRepo.updateTheItemInfo(item);
        Cart cart = cartRepo.addItemToCart(userId, item.getId());
        return cart;
    }

    private void checkItemAvailability(Item item) throws ItemOutOfStockException {
        if (item.getQuantity() == 0) {
            throw new ItemOutOfStockException("Item " + item.getName() + "is out of stock");
        }
    }

    private void validateInput(AddItemDto addItemDto) throws BadRequestException {
        if (Objects.isNull(addItemDto.getUser())) {
            throw new BadRequestException("User cannot be null");
        }
        if (Objects.isNull(addItemDto.getItem())) {
            throw new BadRequestException("Item cannot be null");
        }
    }

}
