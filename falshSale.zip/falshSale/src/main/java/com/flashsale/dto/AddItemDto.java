package com.flashsale.dto;

import com.flashsale.model.Item;
import com.flashsale.model.User;
import lombok.Data;

@Data
public class AddItemDto {
    private User user;
    private Item item;

}
