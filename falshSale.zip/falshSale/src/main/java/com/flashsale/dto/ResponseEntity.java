package com.flashsale.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ResponseEntity<T> {
    private T responseBody;
    private Integer responseStatus;
    private String responseMessage;
}
