package com.flashsale.controller;

import com.flashsale.dto.AddItemDto;
import com.flashsale.dto.ResponseEntity;
import com.flashsale.model.Cart;
import com.flashsale.service.FlashSaleService;
import org.springframework.beans.factory.annotation.Autowired;

@org.springframework.stereotype.Controller
public class Controller {

    @Autowired
    private FlashSaleService flashSaleService;

    @PostMapping("/addItemToCart")
    public ResponseEntity<Cart> addItemToCart(AddItemDto addItemDto){
        return flashSaleService.addItemToCart(addItemDto);
    }
}
