package com.flashsale.exception;

public class AlreadyOrderedException extends Exception {
    public AlreadyOrderedException(String message) {
        super(message);
    }
}
