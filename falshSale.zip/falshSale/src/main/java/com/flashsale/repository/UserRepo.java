package com.flashsale.repository;

import com.flashsale.model.User;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepo {
    User getByUserId(String userId);
}
