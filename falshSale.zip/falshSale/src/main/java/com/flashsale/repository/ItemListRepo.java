package com.flashsale.repository;

import com.flashsale.model.ItemList;

public interface ItemListRepo {
    ItemList getItemListByUserId(String userId);

}
