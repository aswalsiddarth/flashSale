package com.flashsale.repository;

import com.flashsale.model.Cart;
import org.springframework.stereotype.Repository;

@Repository
public interface CartRepo {
    Cart addItemToCart(String userId, String itemId);
    void removeItemFromCart(String userId, String itemId);
    Cart getByUserid(String userId);
}
