package com.flashsale.repository;

import com.flashsale.model.Item;
import org.springframework.stereotype.Repository;

@Repository
public interface ItemRepo {
    void addQuantityOfItems(Item item);
    void updateTheItemInfo(Item item);
    Item getItemById(String itemId);
}
