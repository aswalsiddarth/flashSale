package com.flashsale.model;
import lombok.Data;

@Data
public class Order {
    //Auto incremental id
    private String id;
    private User user;


}
