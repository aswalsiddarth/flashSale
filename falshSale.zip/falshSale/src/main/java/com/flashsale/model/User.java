package com.flashsale.model;

import lombok.Data;

@Data
@Entity
public class User {
    private String id;
    @OneToOne
    private Cart cart;
    @OneToMany
    private Order order;
}
