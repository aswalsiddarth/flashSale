package com.flashsale.model;

import lombok.Data;

import java.util.HashSet;

@Data
public class ItemList {
    private User id;
    private HashSet<Item> items;
}
