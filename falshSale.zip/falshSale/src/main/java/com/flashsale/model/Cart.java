package com.flashsale.model;

import lombok.Data;

import java.util.List;

@Data
public class Cart {
    private String id;
    // @OneToMany
    private List<Item> items;
    private Double totalCartPrice;
}


